# CE 766 — Upper Lake preliminary data package

This folder contains small, traceable data tables used for the preliminary progress update on Upper Lake (Bhojtal), Bhopal.

## Files
- `upper_lake_bod_monthly_mean_2024.csv`: four monthly mean BOD values transcribed from EPCO's 2024 Upper Lake water-quality report. These values support the attached preliminary chart; they are not raw laboratory observations.
- `upper_lake_phosphorus_literature_summary_2018.csv`: published summary statistics for total phosphorus at 15 inflow locations. This is a literature summary, not a site-by-site dataset.
- `upper_lake_bod_chart_revised.png`: preliminary BOD chart for the Moodle submission.
- `sources.txt`: bibliographic details and URLs.

## Important limitations
The BOD series covers only January–April 2024 and should not be interpreted as evidence of a long-term trend. The phosphorus summary is from a 2018 study and is not a current baseline. The optimization model has not yet been run; results are descriptive at this stage.

## Sources
1. Environmental Planning & Coordination Organisation (EPCO). (2024). *Water Quality of Upper Lake 2024*. https://epco.mp.gov.in/uploads/media/Upper_Lake_2024.pdf
2. Mounissamy, V. C., Kundu, S., Saha, J. K., Rajendiran, S., Dotaniya, M. L., Meena, V., Somasundaram, J., & Patra, A. K. (2018). *Relative contribution of phosphorus from various sources to the Upper Lake, Bhopal*. https://doi.org/10.1007/978-981-10-5792-2_36
